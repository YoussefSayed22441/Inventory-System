﻿namespace Inventory_System.API.Responses
{
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public object Meta { get; set; }
    }
}
